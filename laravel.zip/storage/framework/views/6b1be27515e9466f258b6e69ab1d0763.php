<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Humbuah</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
</head>

<body>
    <div class="w-full h-auto">
        <?php echo $__env->make('Components/Navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="mt-16">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
    
</body>

</html>
<?php /**PATH D:\Kuliah\Semester 6\Pemrograman Web 2\Humbuah\resources\views/Layout/Main.blade.php ENDPATH**/ ?>
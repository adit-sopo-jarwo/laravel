<?php $__env->startSection('content'); ?>
    <div class="flex flex-col">
        <div class="-m-1.5 overflow-x-auto">
            <div class="p-1.5 min-w-full inline-block align-middle">
                <div class="flex justify-between mb-6 mx-8">
                    <a href="<?php echo e(route('Create')); ?>"
                        class="bg-blue-600 hover:bg-blue-700 shadow-md py-2 px-8 rounded-md">Add Fruit</a>

                    <?php if(Session::has('success')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(Session::get('success')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="relative"
                        data-hs-combo-box='{
                        "groupingType": "default",
                        "isOpenOnFocus": true,
                        "apiUrl": "../assets/data/searchbox.json",
                        "apiGroupField": "category",
                        "outputItemTemplate": "<div data-hs-combo-box-output-item>
                            <span class=\"flex items-center cursor-pointer py-2 px-4 w-full text-sm text-gray-800 hover:bg-gray-100 focus:outline-none focus:bg-gray-100 dark:bg-neutral-800 dark:hover:bg-neutral-700 dark:text-neutral-200 dark:focus:bg-neutral-700\">
                            <div class=\"flex items-center w-full\">
                                <div class=\"flex items-center justify-center rounded-full bg-gray-200 size-6 overflow-hidden me-2.5\">
                                    <img class=\"flex-shrink-0\" data-hs-combo-box-output-item-attr=&apos;[{\"valueFrom\": \"image\", \"attr\": \"src\"}, {\"valueFrom\": \"name\", \"attr\": \"alt\"}]&apos; />
                                </div>
                                <div data-hs-combo-box-output-item-field=\"name\" data-hs-combo-box-search-text data-hs-combo-box-value>
                                    </div>
                                </div>
                                <span class=\"hidden hs-combo-box-selected:block\">
                                    <svg class=\"flex-shrink-0 size-3.5 text-blue-600 dark:text-blue-500\" xmlns=\"http:.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\">
                                        <polyline points=\"20 6 9 17 4 12\"></polyline>
                                    </svg>
                                </span>
                            </span>
                        </div>",
                        "groupingTitleTemplate": "<div class=\"text-xs uppercase text-gray-500 m-3 mb-1 dark:text-neutral-500\"></div>"
                      }'>
                        <div class="relative">
                            <input
                                class="py-3 ps-7 pe-3 block w-full border-gray-200 rounded-lg text-sm focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none dark:bg-gray-100 dark:border-neutral-700 dark:text-black dark:placeholder-neutral-500 dark:focus:ring-neutral-600"
                                type="text" placeholder="Search Fruits" value="" data-hs-combo-box-input="">
                            <div class="absolute inset-y-0 end-3 flex items-center z-20 ps-3.5">
                                <button>
                                    <svg class="flex-shrink-0 size-4 text-black dark:text-black"
                                        xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                        fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                        stroke-linejoin="round">
                                        <circle cx="11" cy="11" r="8"></circle>
                                        <path d="m21 21-4.3-4.3"></path>
                                    </svg>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="border rounded-lg shadow overflow-hidden px-2">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th scope="col" class="px-6 py-3 text-start font-medium text-gray-500 uppercase">
                                    Name</th>
                                <th scope="col" class="px-6 py-3 text-start font-medium text-gray-500 uppercase">
                                    Age</th>
                                <th scope="col" class="px-6 py-3 text-start font-medium text-gray-500 uppercase">
                                    Address</th>
                                <th scope="col" class="pr-16 py-3 text-end font-medium text-gray-500 uppercase">
                                    Action</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200">
                            <tr>
                                <td class="px-6 py-4 whitespace-nowrap font-medium text-gray-800">John Brown</td>
                                <td class="px-6 py-4 whitespace-nowrap text-gray-800">45</td>
                                <td class="px-6 py-4 whitespace-nowrap text-gray-800">New York No. 1 Lake Park</td>
                                <td class="px-6 py-4 whitespace-nowrap text-end font-medium justify-end">
                                    <a href=""
                                        class="inline-block bg-yellow-400 hover:bg-yellow-500 focus:outline-none focus:ring focus:ring-yellow-300 rounded-md py-2 px-4 transition duration-300">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                            fill="currentColor" class="bi bi-pencil-fill inline-block mr-1"
                                            viewBox="0 0 16 16">
                                            <path
                                                d="m13.498.795.149-.149a1.207 1.207 0 1 1 1.707 1.708l-.149.148a1.5 1.5 0 0 1-.059 2.059L4.854 14.854a.5.5 0 0 1-.233.131l-4 1a.5.5 0 0 1-.606-.606l1-4a.5.5 0 0 1 .131-.232l9.642-9.642a.5.5 0 0 0-.642.056L6.854 4.854a.5.5 0 1 1-.708-.708L9.44.854A1.5 1.5 0 0 1 11.5.796a1.5 1.5 0 0 1 1.998-.001m-.644.766a.5.5 0 0 0-.707 0L1.95 11.756l-.764 3.057 3.057-.764L14.44 3.854a.5.5 0 0 0 0-.708z" />
                                        </svg>
                                        Edit
                                    </a>
                                    <a href=""
                                        class="inline-block bg-red-500 hover:bg-red-600 focus:outline-none focus:ring focus:ring-red-300 rounded-md py-2 px-4 ml-2 transition duration-300">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                            fill="currentColor" class="bi bi-trash-fill inline-block mr-1"
                                            viewBox="0 0 16 16">
                                            <path
                                                d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0z" />
                                            <path
                                                d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4zM2.5 3h11V2h-11z" />
                                        </svg> Delete
                                    </a>
                                    <form action="/" method="post" type="button"
                                        onsubmit="return confirm('Are You Sure Wanna Delete It?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        
                                    </form>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout/Main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester 6\Pemrograman Web 2\Humbuah\resources\views/Buah/Index.blade.php ENDPATH**/ ?>